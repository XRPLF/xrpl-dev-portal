#!/usr/bin/env node
/**
 * scripts/issue-credential.js
 * ─────────────────────────────────────────────────────────────────────────────
 * Step 2: Issue an XLS-70 credential + write a PDR on XRPL Testnet.
 *
 * What this does (the full PCC Bridge flow):
 *   1. Builds a W3C VC 2.0 envelope with compliance claims
 *   2. Generates a Policy Decision Record (PDR)
 *   3. Submits CredentialCreate to XRPL Testnet (XLS-70)
 *   4. Encodes the PDR summary as XRPL memo fields (on-chain anchor)
 *   5. Saves the full VC + PDR to disk
 *   6. Prints the XRPL explorer link to the live transaction
 *
 * Usage:
 *   node scripts/issue-credential.js
 * ─────────────────────────────────────────────────────────────────────────────
 */

import "dotenv/config";
import { Wallet }       from "xrpl";
import { withClient }   from "../src/xrpl-client.js";
import {
  buildVC,
  buildPDR,
  buildMemos,
  generatePdrId,
  credentialTypeToHex,
}                       from "../src/pcc-bridge.js";
import { savePDR, updatePDR } from "../src/pdr-store.js";

// ── Config ────────────────────────────────────────────────────────────────────
const ISSUER_SEED       = process.env.ISSUER_SEED;
const SUBJECT_ADDRESS   = process.env.SUBJECT_ADDRESS;
const CREDENTIAL_TYPE   = process.env.CREDENTIAL_TYPE_HEX
                          || "4b59432d4c322d454e48414e434544"; // KYC-L2-ENHANCED

if (!ISSUER_SEED || !SUBJECT_ADDRESS) {
  console.error("\n✗  Missing env vars. Run: npm run setup\n");
  process.exit(1);
}

// ── Compliance claims — customise for your use case ───────────────────────────
const COMPLIANCE_CLAIMS = {
  kycTier:      "L2",
  jurisdiction: "US-FinCEN",
  ruleSet:      "FATF-R16",
  kycVendor:    "Persona",           // swap to Jumio / Veriff etc.
  entityType:   "FinancialInstitution",
  amlClear:     true,
  sanctions:    "OFAC-CLEAR",
};

// ── Helpers ──────────────────────────────────────────────────────────────────
const g    = s => `\x1b[32m${s}\x1b[0m`;
const b    = s => `\x1b[34m${s}\x1b[0m`;
const y    = s => `\x1b[33m${s}\x1b[0m`;
const d    = s => `\x1b[2m${s}\x1b[0m`;
const bold = s => `\x1b[1m${s}\x1b[0m`;
const spin = ["⠋","⠙","⠹","⠸","⠼","⠴","⠦","⠧","⠇","⠏"];

function spinner(label) {
  let i = 0;
  const t = setInterval(() => {
    process.stdout.write(`\r  ${spin[i++ % spin.length]}  ${label}   `);
  }, 80);
  return () => { clearInterval(t); process.stdout.write(`\r  ${g("✓")}  ${label}\n`); };
}

// ── Expiry: 1 year from now ───────────────────────────────────────────────────
function expiryISO() {
  const d = new Date();
  d.setFullYear(d.getFullYear() + 1);
  return d.toISOString();
}

// ── XRPL ripple epoch (seconds since Jan 1 2000) ─────────────────────────────
function toRippleEpoch(isoDate) {
  const RIPPLE_EPOCH_OFFSET = 946684800; // Unix timestamp of 2000-01-01
  return Math.floor(new Date(isoDate).getTime() / 1000) - RIPPLE_EPOCH_OFFSET;
}

// ── Main ──────────────────────────────────────────────────────────────────────
async function main() {
  console.log("\n" + bold("PCC Protocol — Issue Credential + Write PDR"));
  console.log(d("─────────────────────────────────────────────────────"));

  const issuerWallet = Wallet.fromSeed(ISSUER_SEED);
  const pdrId        = generatePdrId();
  const expiry       = expiryISO();

  console.log(`  Issuer:  ${b(issuerWallet.address)}`);
  console.log(`  Subject: ${b(SUBJECT_ADDRESS)}`);
  console.log(`  PDR ID:  ${y(pdrId)}`);
  console.log(`  Schema:  KYC-L2-ENHANCED (FATF-R16 / US-FinCEN)`);
  console.log(d("─────────────────────────────────────────────────────\n"));

  // ── Step 1: Build W3C VC 2.0 ────────────────────────────────────────────
  const done1 = spinner("Building W3C VC 2.0 envelope…");
  await new Promise(r => setTimeout(r, 400));

  const vc = buildVC({
    issuerAddress:  issuerWallet.address,
    subjectAddress: SUBJECT_ADDRESS,
    credentialType: "KYC-L2-ENHANCED",
    claims:         COMPLIANCE_CLAIMS,
    pdrId,
    expiryISO:      expiry,
  });
  done1();

  // ── Step 2: Build PDR ────────────────────────────────────────────────────
  const done2 = spinner("Generating Policy Decision Record…");
  await new Promise(r => setTimeout(r, 300));

  const pdr = buildPDR({ vc, vcHash: "PENDING_IPFS" });
  savePDR(pdr, vc); // persist before tx in case of failure
  done2();

  // ── Step 3: Build XRPL transaction ──────────────────────────────────────
  const done3 = spinner("Encoding PDR as XRPL memo fields…");
  await new Promise(r => setTimeout(r, 300));

  const memos = buildMemos(pdr);
  done3();

  // ── Step 4: Submit CredentialCreate to testnet ───────────────────────────
  const done4 = spinner("Submitting CredentialCreate to XRPL Testnet…");

  let txResult;
  await withClient(async (client) => {
    const tx = {
      TransactionType: "CredentialCreate",
      Account:         issuerWallet.address,   // issuer
      Subject:         SUBJECT_ADDRESS,         // credential holder
      CredentialType:  CREDENTIAL_TYPE,         // hex-encoded type

      // Expiry in Ripple epoch seconds
      Expiration: toRippleEpoch(expiry),

      // URI pointing to the full W3C VC 2.0 document (off-chain)
      // In production: IPFS CID of the signed VC JSON
      URI: Buffer.from(`https://pcc.protocol/credentials/${pdrId}`, "utf8")
               .toString("hex")
               .toUpperCase(),

      // PDR memo fields — the on-chain anchor
      Memos: memos,
    };

    txResult = await client.submitAndWait(tx, { wallet: issuerWallet });
  });

  done4();

  // ── Step 5: Update PDR with real txHash ──────────────────────────────────
  const done5 = spinner("Anchoring PDR hash to transaction…");
  await new Promise(r => setTimeout(r, 200));

  const txHash = txResult?.result?.hash || "UNKNOWN";
  const updatedPdr = updatePDR(pdr.id, {
    "issuance.xrplTxHash": txHash,
    "issuance.vcHash":     `sha256:${pdrId}`, // placeholder — use real hash in prod
    status: txResult?.result?.meta?.TransactionResult === "tesSUCCESS"
              ? "VALID"
              : "FAILED",
  });
  done5();

  // ── Summary ───────────────────────────────────────────────────────────────
  const success = txResult?.result?.meta?.TransactionResult === "tesSUCCESS";
  console.log("");
  console.log(d("─────────────────────────────────────────────────────"));

  if (success) {
    console.log(g("\n✓  Credential issued + PDR written successfully\n"));
    console.log(bold("XRPL Transaction:"));
    console.log(`   Hash:    ${b(txHash)}`);
    console.log(`   Ledger:  ${txResult?.result?.ledger_index}`);
    console.log(`   Explorer: https://testnet.xrpl.org/transactions/${txHash}`);
    console.log("");
    console.log(bold("PDR Record:"));
    console.log(`   ID:      ${y(pdr.id)}`);
    console.log(`   Status:  ${g("VALID")}`);
    console.log(`   Schema:  ${pdr.policy.credentialSchema}`);
    console.log(`   Tier:    ${pdr.policy.kycTier}`);
    console.log(`   Expires: ${pdr.issuance.expiresAt.slice(0, 10)}`);
    console.log("");
    console.log(bold("Files written:"));
    console.log(`   VC:  output/vcs/${pdr.id}.json`);
    console.log(`   PDR: output/pdrs.json  (appended)`);
    console.log("");
    console.log(y("Next steps:"));
    console.log(`   npm run verify    — verify the credential on-chain`);
    console.log(`   npm run explorer  — browse all PDRs`);
    console.log(`   npm run revoke    — revoke this credential`);
    console.log(`   PDR_ID=${pdr.id}`);
  } else {
    console.log("\x1b[31m✗  Transaction failed:\x1b[0m",
      txResult?.result?.meta?.TransactionResult);
    console.log("Full result:", JSON.stringify(txResult?.result, null, 2));
  }

  console.log(d("─────────────────────────────────────────────────────\n"));
}

main().catch(err => {
  console.error("\n\x1b[31m✗  Error:\x1b[0m", err.message);
  if (err.data) console.error("XRPL Error:", JSON.stringify(err.data, null, 2));
  process.exit(1);
});
