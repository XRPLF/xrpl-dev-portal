#!/usr/bin/env node
/**
 * scripts/setup-wallets.js
 * ─────────────────────────────────────────────────────────────────────────────
 * Step 1: Run this first.
 *
 * Creates and funds two XRPL testnet wallets:
 *   - ISSUER  (the PCC Bridge / KYC vendor account)
 *   - SUBJECT (the entity receiving the credential — bank, AI agent, etc.)
 *
 * Writes credentials to .env automatically.
 *
 * Usage:
 *   node scripts/setup-wallets.js
 * ─────────────────────────────────────────────────────────────────────────────
 */

import { Wallet }      from "xrpl";
import fs              from "fs";
import path            from "path";
import { fileURLToPath } from "url";
import { withClient }  from "../src/xrpl-client.js";

const __dir  = path.dirname(fileURLToPath(import.meta.url));
const ENV    = path.join(__dir, "../.env");
const OUTPUT = path.join(__dir, "../output");

// Simple terminal colors without chalk dependency at setup time
const g  = s => `\x1b[32m${s}\x1b[0m`;
const b  = s => `\x1b[34m${s}\x1b[0m`;
const y  = s => `\x1b[33m${s}\x1b[0m`;
const d  = s => `\x1b[2m${s}\x1b[0m`;
const bold = s => `\x1b[1m${s}\x1b[0m`;

async function main() {
  fs.mkdirSync(OUTPUT, { recursive: true });

  console.log("\n" + bold("PCC Protocol — Testnet Setup"));
  console.log(d("─────────────────────────────────────────────"));
  console.log("Connecting to XRPL Testnet…\n");

  await withClient(async (client) => {

    // ── Fund Issuer wallet ─────────────────────────────────────────────────
    process.stdout.write("Funding ISSUER wallet (PCC Bridge)… ");
    const { wallet: issuer, balance: issuerBalance } = await client.fundWallet();
    console.log(g(`✓  ${issuerBalance} XRP`));
    console.log(`   Address: ${b(issuer.address)}`);
    console.log(`   Seed:    ${d(issuer.seed)}\n`);

    // ── Fund Subject wallet ────────────────────────────────────────────────
    process.stdout.write("Funding SUBJECT wallet (bank / agent)… ");
    const { wallet: subject, balance: subjectBalance } = await client.fundWallet();
    console.log(g(`✓  ${subjectBalance} XRP`));
    console.log(`   Address: ${b(subject.address)}`);
    console.log(`   Seed:    ${d(subject.seed)}\n`);

    // ── Write .env ─────────────────────────────────────────────────────────
    const envContent = [
      "# PCC Protocol — Testnet Environment",
      `# Generated: ${new Date().toISOString()}`,
      "",
      "XRPL_SERVER=wss://s.altnet.rippletest.net:51233",
      "",
      "# Issuer wallet (PCC Bridge / KYC vendor)",
      `ISSUER_SEED=${issuer.seed}`,
      `ISSUER_ADDRESS=${issuer.address}`,
      "",
      "# Subject wallet (credential holder — bank, AI agent, etc.)",
      `SUBJECT_SEED=${subject.seed}`,
      `SUBJECT_ADDRESS=${subject.address}`,
      "",
      "# Credential type (hex of 'KYC-L2-ENHANCED')",
      "CREDENTIAL_TYPE_HEX=4b59432d4c322d454e48414e434544",
    ].join("\n");

    fs.writeFileSync(ENV, envContent);

    // ── Summary ────────────────────────────────────────────────────────────
    console.log(d("─────────────────────────────────────────────"));
    console.log(g("✓  .env written successfully\n"));
    console.log(bold("Testnet Explorer Links:"));
    console.log(`   Issuer:  https://testnet.xrpl.org/accounts/${issuer.address}`);
    console.log(`   Subject: https://testnet.xrpl.org/accounts/${subject.address}`);
    console.log("");
    console.log(y("Next step:  npm run issue"));
    console.log(d("─────────────────────────────────────────────\n"));
  });
}

main().catch(err => {
  console.error("\n\x1b[31m✗  Setup failed:\x1b[0m", err.message);
  process.exit(1);
});
