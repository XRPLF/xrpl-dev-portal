#!/usr/bin/env node
/**
 * scripts/revoke-credential.js
 * ─────────────────────────────────────────────────────────────────────────────
 * Revokes an XRPL XLS-70 credential and updates the local PDR store.
 *
 * Revocation on XRPL = CredentialDelete transaction from the issuer.
 * The PDR is updated to status REVOKED with a revocation timestamp.
 *
 * In production: revocation triggers a pub/sub event that propagates to
 *   all registered domain operators, EVM relayers, and bank API webhooks.
 *
 * Usage:
 *   PDR_ID=PDR-xxxx node scripts/revoke-credential.js
 * ─────────────────────────────────────────────────────────────────────────────
 */

import "dotenv/config";
import { Wallet }       from "xrpl";
import { withClient }   from "../src/xrpl-client.js";
import { toHex }        from "../src/pcc-bridge.js";
import { getPDR, updatePDR, loadStore } from "../src/pdr-store.js";

const g    = s => `\x1b[32m${s}\x1b[0m`;
const r    = s => `\x1b[31m${s}\x1b[0m`;
const b    = s => `\x1b[34m${s}\x1b[0m`;
const y    = s => `\x1b[33m${s}\x1b[0m`;
const d    = s => `\x1b[2m${s}\x1b[0m`;
const bold = s => `\x1b[1m${s}\x1b[0m`;

const CREDENTIAL_TYPE = process.env.CREDENTIAL_TYPE_HEX || "4b59432d4c322d454e48414e434544";

async function main() {
  // ── Identify target PDR ───────────────────────────────────────────────────
  const targetId = process.env.PDR_ID;
  let pdr;

  if (targetId) {
    pdr = getPDR(targetId);
    if (!pdr) {
      console.error(r(`\n✗  PDR not found: ${targetId}\n`));
      process.exit(1);
    }
  } else {
    const valid = loadStore().filter(p => p.status === "VALID");
    if (valid.length === 0) {
      console.error(r("\n✗  No VALID PDRs to revoke. Run: npm run issue\n"));
      process.exit(1);
    }
    pdr = valid[0];
    console.log(d(`\n  (No PDR_ID set — revoking most recent VALID PDR: ${pdr.id})`));
  }

  if (pdr.status === "REVOKED") {
    console.log(y(`\n⚠  PDR ${pdr.id} is already REVOKED\n`));
    process.exit(0);
  }

  const issuerWallet   = Wallet.fromSeed(process.env.ISSUER_SEED);
  const subjectAddress = pdr.subject?.xrplAddress;

  console.log("\n" + bold("PCC Protocol — Revoke Credential"));
  console.log(d("─────────────────────────────────────────────────────"));
  console.log(`  PDR ID:  ${y(pdr.id)}`);
  console.log(`  Subject: ${b(subjectAddress)}`);
  console.log(`  Schema:  ${pdr.policy?.credentialSchema}`);
  console.log(d("─────────────────────────────────────────────────────\n"));

  // ── Submit CredentialDelete ───────────────────────────────────────────────
  process.stdout.write("  Submitting CredentialDelete to XRPL Testnet… ");

  let txResult;
  await withClient(async (client) => {
    const tx = {
      TransactionType: "CredentialDelete",
      Account:         issuerWallet.address,
      Subject:         subjectAddress,
      CredentialType:  CREDENTIAL_TYPE,
      Memos: [{
        Memo: {
          MemoType:   toHex("pcc/revoke"),
          MemoData:   toHex(JSON.stringify({
            pdrId:       pdr.id,
            reason:      "Issuer-initiated revocation",
            revokedAt:   new Date().toISOString(),
            propagate:   ["XRPL", "EVM-PENDING", "BANK-API-PENDING"],
          })),
          MemoFormat: toHex("application/json"),
        },
      }],
    };

    txResult = await client.submitAndWait(tx, { wallet: issuerWallet });
  });

  const success = txResult?.result?.meta?.TransactionResult === "tesSUCCESS";
  console.log(success ? g("✓") : r("✗"));

  if (!success) {
    console.error(r("\n✗  Revocation transaction failed:"),
      txResult?.result?.meta?.TransactionResult);
    process.exit(1);
  }

  // ── Update PDR store ──────────────────────────────────────────────────────
  const revokedAt = new Date().toISOString();
  updatePDR(pdr.id, {
    status: "REVOKED",
    revocation: {
      revokedAt,
      revokedBy:      issuerWallet.address,
      revokeTxHash:   txResult?.result?.hash,
      propagatedTo:   ["XRPL"],
      pendingRelay:   ["EVM", "Bank-API"],
    },
  });

  const txHash = txResult?.result?.hash;
  console.log("");
  console.log(g("✓  Credential revoked successfully\n"));
  console.log(bold("XRPL Transaction:"));
  console.log(`   Hash:     ${b(txHash)}`);
  console.log(`   Ledger:   ${txResult?.result?.ledger_index}`);
  console.log(`   Explorer: https://testnet.xrpl.org/transactions/${txHash}`);
  console.log("");
  console.log(bold("PDR Updated:"));
  console.log(`   Status:     ${r("REVOKED")}`);
  console.log(`   Revoked At: ${revokedAt.slice(0,19)} UTC`);
  console.log("");
  console.log(bold("Propagation Status:"));
  console.log(`   ${g("✓")} XRPL — credential deleted from ledger`);
  console.log(`   ${y("⏳")} EVM relay — implement in src/evm-relay.js`);
  console.log(`   ${y("⏳")} Bank API webhook — implement in src/bank-webhook.js`);
  console.log(d("\n─────────────────────────────────────────────────────\n"));
}

main().catch(err => {
  console.error(r("\n✗  Revoke failed:"), err.message);
  process.exit(1);
});
