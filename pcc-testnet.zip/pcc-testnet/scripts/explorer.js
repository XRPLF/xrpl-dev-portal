#!/usr/bin/env node
/**
 * scripts/explorer.js
 * ─────────────────────────────────────────────────────────────────────────────
 * Terminal PDR explorer — browse and inspect all local PDR records.
 *
 * Usage:
 *   node scripts/explorer.js              # list all PDRs
 *   node scripts/explorer.js --valid      # only VALID
 *   node scripts/explorer.js --revoked    # only REVOKED
 *   node scripts/explorer.js --json       # raw JSON output
 * ─────────────────────────────────────────────────────────────────────────────
 */

import { loadStore, loadVC } from "../src/pdr-store.js";

const g    = s => `\x1b[32m${s}\x1b[0m`;
const r    = s => `\x1b[31m${s}\x1b[0m`;
const b    = s => `\x1b[34m${s}\x1b[0m`;
const y    = s => `\x1b[33m${s}\x1b[0m`;
const d    = s => `\x1b[2m${s}\x1b[0m`;
const bold = s => `\x1b[1m${s}\x1b[0m`;
const cyan = s => `\x1b[36m${s}\x1b[0m`;

function statusColor(status) {
  if (status === "VALID")   return g(status);
  if (status === "REVOKED") return r(status);
  if (status === "PENDING") return y(status);
  return d(status);
}

function bar(len = 53) { return d("─".repeat(len)); }

function main() {
  const args    = process.argv.slice(2);
  const rawJson = args.includes("--json");
  const onlyValid   = args.includes("--valid");
  const onlyRevoked = args.includes("--revoked");

  let pdrs = loadStore();

  if (pdrs.length === 0) {
    console.log(y("\n  No PDRs found. Run: npm run issue\n"));
    process.exit(0);
  }

  if (onlyValid)   pdrs = pdrs.filter(p => p.status === "VALID");
  if (onlyRevoked) pdrs = pdrs.filter(p => p.status === "REVOKED");

  if (rawJson) {
    console.log(JSON.stringify(pdrs, null, 2));
    return;
  }

  // ── Header ────────────────────────────────────────────────────────────────
  console.log("\n" + bold("PCC Protocol — PDR Explorer"));
  console.log(bar());
  console.log(
    `  ${bold(String(pdrs.length).padStart(3))} record(s)  ` +
    `${g(pdrs.filter(p=>p.status==="VALID").length + " VALID")}  ` +
    `${r(pdrs.filter(p=>p.status==="REVOKED").length + " REVOKED")}  ` +
    `${y(pdrs.filter(p=>p.status==="PENDING").length + " PENDING")}`
  );
  console.log(bar());

  // ── PDR List ──────────────────────────────────────────────────────────────
  pdrs.forEach((pdr, i) => {
    const isLast = i === pdrs.length - 1;
    const vc     = loadVC(pdr.id);

    // Card header
    console.log("");
    console.log(
      `  ${cyan(pdr.id.padEnd(26))} ${statusColor(pdr.status).padEnd(12)}` +
      `${d(pdr.issuance?.issuedAt?.slice(0,10) || "—")}`
    );

    // Subject
    console.log(
      `  ${d("Subject:")}  ${b((pdr.subject?.xrplAddress || "—").slice(0, 34))}…`
    );

    // Policy
    console.log(
      `  ${d("Schema:")}   ${pdr.policy?.credentialSchema || "—"}  ` +
      `${d("Tier:")} ${pdr.policy?.kycTier || "—"}  ` +
      `${d("Rules:")} ${pdr.policy?.ruleSetID || "—"}  ` +
      `${d("Juris:")} ${pdr.policy?.jurisdiction || "—"}`
    );

    // Chain
    const tx = pdr.issuance?.xrplTxHash;
    if (tx && tx !== "PENDING" && tx !== "UNKNOWN") {
      console.log(
        `  ${d("Tx:")}       ${b(tx.slice(0, 20))}…  ` +
        `${d("https://testnet.xrpl.org/transactions/" + tx.slice(0, 8) + "…")}`
      );
    } else {
      console.log(`  ${d("Tx:")}       ${y("PENDING")}`);
    }

    // VC
    console.log(
      `  ${d("VC:")}       ${vc ? g("W3C-VC-2.0 ✓") : y("NOT FOUND")}  ` +
      `${d("Expires:")} ${pdr.issuance?.expiresAt?.slice(0,10) || "—"}`
    );

    // Revocation info
    if (pdr.revocation) {
      console.log(
        `  ${r("Revoked:")}  ${pdr.revocation.revokedAt?.slice(0,19) || "—"} UTC  ` +
        `${d("by")} ${pdr.revocation.revokedBy?.slice(0,12)}…`
      );
    }

    if (!isLast) console.log(`  ${bar(51)}`);
  });

  // ── Footer ────────────────────────────────────────────────────────────────
  console.log("\n" + bar());
  console.log(bold("  Commands:"));
  console.log(`  ${d("npm run issue")}   — issue a new credential + write PDR`);
  console.log(`  ${d("npm run verify")}  — verify most recent PDR on-chain`);
  console.log(`  ${d("npm run revoke")}  — revoke most recent VALID credential`);
  console.log(`  ${d("PDR_ID=<id> npm run verify")}  — verify specific PDR`);
  console.log(bar());
  console.log("");
}

main();
