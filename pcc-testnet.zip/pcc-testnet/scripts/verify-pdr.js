#!/usr/bin/env node
/**
 * scripts/verify-pdr.js
 * ─────────────────────────────────────────────────────────────────────────────
 * Verifies a PDR by:
 *   1. Looking up the XRPL credential object on-chain (account_objects)
 *   2. Decoding the PDR memo fields from the issuance transaction
 *   3. Cross-referencing with the local PDR store
 *   4. Printing a structured verification report
 *
 * Usage:
 *   node scripts/verify-pdr.js                        # verifies most recent PDR
 *   PDR_ID=PDR-xxxx node scripts/verify-pdr.js        # verifies specific PDR
 * ─────────────────────────────────────────────────────────────────────────────
 */

import "dotenv/config";
import { withClient }       from "../src/xrpl-client.js";
import { decodeMemosToPDR, hexToCredentialType } from "../src/pcc-bridge.js";
import { loadStore, getPDR, loadVC } from "../src/pdr-store.js";

const g    = s => `\x1b[32m${s}\x1b[0m`;
const r    = s => `\x1b[31m${s}\x1b[0m`;
const b    = s => `\x1b[34m${s}\x1b[0m`;
const y    = s => `\x1b[33m${s}\x1b[0m`;
const d    = s => `\x1b[2m${s}\x1b[0m`;
const bold = s => `\x1b[1m${s}\x1b[0m`;

function row(label, value, color = v => v) {
  const pad = label.padEnd(22);
  console.log(`   ${d(pad)} ${color(value)}`);
}

async function main() {
  // ── Pick target PDR ───────────────────────────────────────────────────────
  const targetId = process.env.PDR_ID;
  let pdr;

  if (targetId) {
    pdr = getPDR(targetId);
    if (!pdr) {
      console.error(r(`\n✗  PDR not found locally: ${targetId}`));
      console.error("   Run: npm run explorer  to list all PDRs\n");
      process.exit(1);
    }
  } else {
    const all = loadStore();
    if (all.length === 0) {
      console.error(r("\n✗  No PDRs found. Run: npm run issue\n"));
      process.exit(1);
    }
    pdr = all[0];
    console.log(d(`  (No PDR_ID set — verifying most recent: ${pdr.id})\n`));
  }

  console.log("\n" + bold("PCC Protocol — PDR Verification Report"));
  console.log(d("─────────────────────────────────────────────────────\n"));

  // ── Check 1: Local PDR record ─────────────────────────────────────────────
  console.log(bold("  [1] Local PDR Record"));
  row("PDR ID",         pdr.id,  y);
  row("Status",         pdr.status, pdr.status === "VALID" ? g : r);
  row("Subject",        pdr.subject?.xrplAddress || "—", b);
  row("Schema",         pdr.policy?.credentialSchema || "—");
  row("Rule Set",       pdr.policy?.ruleSetID || "—");
  row("KYC Tier",       pdr.policy?.kycTier || "—");
  row("Jurisdiction",   pdr.policy?.jurisdiction || "—");
  row("Issued At",      pdr.issuance?.issuedAt?.slice(0,19) + " UTC" || "—");
  row("Expires",        pdr.issuance?.expiresAt?.slice(0,10) || "—");
  row("XRPL Tx Hash",   pdr.issuance?.xrplTxHash?.slice(0,20) + "…" || "—", b);
  console.log("");

  // ── Check 2: W3C VC envelope ──────────────────────────────────────────────
  const vc = loadVC(pdr.id);
  console.log(bold("  [2] W3C VC 2.0 Envelope"));
  if (vc) {
    row("VC ID",          vc.id || "—");
    row("Issuer DID",     vc.issuer?.id?.slice(0,40) + "…" || "—");
    row("Subject DID",    vc.credentialSubject?.id?.slice(0,40) + "…" || "—");
    row("VC Envelope",    "W3C-VC-2.0", g);
    row("Proof Type",     vc.proof?.type || "—");
    row("Proof Suite",    vc.proof?.cryptosuite || "—");
    row("Proof Status",   "PLACEHOLDER (sign with Ed25519 in prod)", y);
  } else {
    row("VC File",        "NOT FOUND", r);
  }
  console.log("");

  // ── Check 3: On-chain verification ───────────────────────────────────────
  console.log(bold("  [3] On-Chain Verification (XRPL Testnet)"));

  const txHash = pdr.issuance?.xrplTxHash;
  const issuerAddress = process.env.ISSUER_ADDRESS;
  const subjectAddress = pdr.subject?.xrplAddress;

  if (!txHash || txHash === "PENDING" || txHash === "UNKNOWN") {
    row("Chain Status",   "No valid tx hash — reissue credential", r);
  } else {
    let chainOk = false;
    let chainCredential = null;
    let memoCheck = null;

    await withClient(async (client) => {
      // Fetch the original transaction
      try {
        const txRes = await client.request({
          command: "tx",
          transaction: txHash,
        });

        const tx = txRes?.result;
        const meta = tx?.meta || tx?.metaData;
        const txSuccess = meta?.TransactionResult === "tesSUCCESS";

        row("Tx Found",       txSuccess ? "YES" : "NOT VALIDATED", txSuccess ? g : r);
        row("Tx Type",        tx?.TransactionType || "—");
        row("Ledger Index",   String(tx?.ledger_index || "—"));

        // Decode PDR memos from the transaction
        if (tx?.Memos?.length) {
          const { summary, uri } = decodeMemosToPDR(tx.Memos);
          if (summary) {
            memoCheck = summary;
            row("Memo PDR ID",   summary.id || "—", y);
            row("Memo Schema",   summary.schema || "—");
            row("Memo Rule Set", summary.ruleSet || "—");
            row("Memo Tier",     summary.tier || "—");
            row("Memo URI",      uri || "—");

            // Cross-reference
            const idMatch     = summary.id === pdr.id;
            const schemaMatch = summary.schema === pdr.policy?.credentialSchema;
            row("PDR ID Match",   idMatch     ? "✓ MATCH" : "✗ MISMATCH", idMatch     ? g : r);
            row("Schema Match",   schemaMatch ? "✓ MATCH" : "✗ MISMATCH", schemaMatch ? g : r);
          } else {
            row("Memo Decode",   "No pcc/pdr memo found", y);
          }
        }

        chainOk = txSuccess;
      } catch (e) {
        row("Chain Lookup",   `Error: ${e.message}`, r);
      }

      // Separately look up the credential object on the subject's account
      if (subjectAddress) {
        try {
          const objRes = await client.request({
            command:      "account_objects",
            account:      subjectAddress,
            type:         "credential",
            ledger_index: "validated",
          });

          const creds = objRes?.result?.account_objects || [];
          row("Subject Credentials", `${creds.length} credential object(s) on-chain`);

          if (creds.length > 0) {
            creds.forEach((c, i) => {
              const type = c.CredentialType
                ? hexToCredentialType(c.CredentialType)
                : c.CredentialType;
              row(`  Credential ${i + 1}`, `${type} (accepted: ${c.Flags === 65536 ? "YES" : "NO"})`,
                c.Flags === 65536 ? g : y);
            });
          }
        } catch (e) {
          row("Subject Lookup",  `Error: ${e.message}`, r);
        }
      }
    });

    // ── Verification score ───────────────────────────────────────────────
    console.log("");
    console.log(bold("  [4] Verification Summary"));
    const checks = [
      ["Local PDR record",   !!pdr],
      ["W3C VC envelope",    !!vc],
      ["XRPL transaction",   chainOk],
      ["PDR memo on-chain",  !!memoCheck],
    ];

    let passed = 0;
    checks.forEach(([label, ok]) => {
      row(label, ok ? "PASS" : "FAIL", ok ? g : r);
      if (ok) passed++;
    });

    console.log("");
    const score = `${passed}/${checks.length} checks passed`;
    console.log(`   ${bold("Score:")} ${passed === checks.length ? g(score) : y(score)}`);

    if (passed === checks.length) {
      console.log(`\n   ${g("✓  PDR verified — credential is portable and on-chain")}`);
    } else {
      console.log(`\n   ${y("⚠  Some checks failed — review above")}`);
    }
  }

  console.log("");
  console.log(d("─────────────────────────────────────────────────────\n"));
}

main().catch(err => {
  console.error(r("\n✗  Verify failed:"), err.message);
  process.exit(1);
});
