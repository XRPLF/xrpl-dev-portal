/**
 * pdr-store.js
 * ─────────────────────────────────────────────────────────────────────────────
 * Simple local JSON store for PDR records.
 *
 * In production this would be:
 *   - A Postgres DB for fast querying
 *   - An IPFS node for content-addressed immutability
 *   - A pub/sub event stream (Redis / Kafka) for real-time propagation
 *
 * For testnet: flat JSON file in ./output/pdrs.json
 * ─────────────────────────────────────────────────────────────────────────────
 */

import fs   from "fs";
import path from "path";
import { fileURLToPath } from "url";

const __dir    = path.dirname(fileURLToPath(import.meta.url));
const STORE    = path.join(__dir, "../output/pdrs.json");
const VC_DIR   = path.join(__dir, "../output/vcs");

/** Ensure output dirs exist */
function ensureDirs() {
  fs.mkdirSync(path.dirname(STORE), { recursive: true });
  fs.mkdirSync(VC_DIR, { recursive: true });
}

/** Load the full PDR store */
export function loadStore() {
  ensureDirs();
  if (!fs.existsSync(STORE)) return [];
  try {
    return JSON.parse(fs.readFileSync(STORE, "utf8"));
  } catch {
    return [];
  }
}

/** Save the full PDR store */
function saveStore(records) {
  ensureDirs();
  fs.writeFileSync(STORE, JSON.stringify(records, null, 2));
}

/**
 * savePDR
 * Persists a PDR + its associated VC to disk.
 *
 * @param {object} pdr - PDR document
 * @param {object} vc  - W3C VC 2.0 document
 */
export function savePDR(pdr, vc) {
  ensureDirs();

  // Write VC to individual file
  const vcPath = path.join(VC_DIR, `${pdr.id}.json`);
  fs.writeFileSync(vcPath, JSON.stringify(vc, null, 2));

  // Append PDR to store
  const records = loadStore();
  const existing = records.findIndex(r => r.id === pdr.id);
  if (existing >= 0) {
    records[existing] = pdr;
  } else {
    records.unshift(pdr); // newest first
  }
  saveStore(records);
}

/**
 * updatePDR
 * Updates an existing PDR record (e.g. to add txHash after submission,
 * or to mark as REVOKED).
 *
 * @param {string} id      - PDR ID
 * @param {object} updates - Partial PDR fields to merge
 */
export function updatePDR(id, updates) {
  const records = loadStore();
  const idx = records.findIndex(r => r.id === id);
  if (idx < 0) throw new Error(`PDR not found: ${id}`);

  records[idx] = { ...records[idx], ...updates };
  saveStore(records);
  return records[idx];
}

/**
 * getPDR
 * Retrieves a single PDR by ID.
 */
export function getPDR(id) {
  return loadStore().find(r => r.id === id) ?? null;
}

/**
 * listPDRs
 * Returns all PDRs, optionally filtered.
 *
 * @param {{ status?: string, address?: string }} filter
 */
export function listPDRs(filter = {}) {
  let records = loadStore();
  if (filter.status)  records = records.filter(r => r.status === filter.status);
  if (filter.address) records = records.filter(
    r => r.subject?.xrplAddress === filter.address ||
         r.issuance?.xrplIssuer === filter.address
  );
  return records;
}

/**
 * loadVC
 * Loads the full W3C VC 2.0 document for a given PDR ID.
 */
export function loadVC(pdrId) {
  const vcPath = path.join(VC_DIR, `${pdrId}.json`);
  if (!fs.existsSync(vcPath)) return null;
  return JSON.parse(fs.readFileSync(vcPath, "utf8"));
}
