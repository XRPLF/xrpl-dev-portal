/**
 * xrpl-client.js
 * ─────────────────────────────────────────────────────────────────────────────
 * Shared XRPL client factory.
 * Handles connection, auto-reconnect, and clean disconnect.
 * ─────────────────────────────────────────────────────────────────────────────
 */

import { Client } from "xrpl";

const TESTNET = "wss://s.altnet.rippletest.net:51233";

let _client = null;

/**
 * getClient
 * Returns a connected, shared XRPL client instance.
 * Creates and connects one if not already alive.
 */
export async function getClient(server = TESTNET) {
  if (_client && _client.isConnected()) return _client;

  _client = new Client(server);
  await _client.connect();

  _client.on("disconnected", () => {
    console.warn("[xrpl] Disconnected from", server);
    _client = null;
  });

  return _client;
}

/**
 * disconnect
 * Cleanly closes the XRPL WebSocket connection.
 */
export async function disconnect() {
  if (_client && _client.isConnected()) {
    await _client.disconnect();
    _client = null;
  }
}

/**
 * withClient
 * Convenience wrapper: connects, runs fn(client), then disconnects.
 *
 * @param {function} fn - async function(client) => result
 * @param {string}   server - optional WebSocket URL
 */
export async function withClient(fn, server = TESTNET) {
  const client = await getClient(server);
  try {
    return await fn(client);
  } finally {
    await disconnect();
  }
}
