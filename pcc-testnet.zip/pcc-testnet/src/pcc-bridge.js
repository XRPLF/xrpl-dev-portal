/**
 * pcc-bridge.js
 * ─────────────────────────────────────────────────────────────────────────────
 * PCC Protocol — Core Bridge Module
 *
 * Responsibilities:
 *  1. Build W3C VC 2.0 envelopes around XRPL XLS-70 credentials
 *  2. Generate Policy Decision Records (PDRs)
 *  3. Encode PDRs as XRPL transaction memos (on-chain anchoring)
 *  4. Verify and decode PDRs from chain
 * ─────────────────────────────────────────────────────────────────────────────
 */

// ── Helpers ──────────────────────────────────────────────────────────────────

/** Encode a UTF-8 string as uppercase hex (XRPL memo format) */
export function toHex(str) {
  return Buffer.from(str, "utf8").toString("hex").toUpperCase();
}

/** Decode XRPL hex memo back to UTF-8 string */
export function fromHex(hex) {
  return Buffer.from(hex, "hex").toString("utf8");
}

/** Encode credential type string → hex (XRPL CredentialType field) */
export function credentialTypeToHex(type) {
  return Buffer.from(type, "utf8").toString("hex").toUpperCase();
}

/** Decode CredentialType hex → human-readable string */
export function hexToCredentialType(hex) {
  return Buffer.from(hex, "hex").toString("utf8");
}

/** Simple deterministic ID from timestamp + random suffix */
export function generatePdrId() {
  const ts = Date.now().toString(36).toUpperCase();
  const rnd = Math.random().toString(36).slice(2, 6).toUpperCase();
  return `PDR-${ts}-${rnd}`;
}

// ── W3C VC 2.0 Envelope ──────────────────────────────────────────────────────

/**
 * buildVC
 * Wraps an XRPL XLS-70 credential into a W3C Verifiable Credential 2.0 document.
 *
 * In production: this envelope is signed with the Bridge's Ed25519 key,
 * published to a content-addressed URI (IPFS or HTTPS), and its hash anchored
 * on-chain via the XRPL memo field.
 *
 * For testnet: we generate the VC document and embed it in the XRPL memo
 * (truncated for memo field size limits). The full VC is written to disk.
 *
 * @param {object} params
 * @param {string} params.issuerAddress     - XRPL address of the PCC Bridge / KYC vendor
 * @param {string} params.subjectAddress    - XRPL address of the credential holder
 * @param {string} params.credentialType    - Human-readable type, e.g. "KYC-L2-ENHANCED"
 * @param {object} params.claims            - Compliance claims to embed
 * @param {string} params.pdrId            - Policy Decision Record ID
 * @param {string} params.expiryISO        - ISO 8601 expiry date
 * @returns {object} W3C VC 2.0 document
 */
export function buildVC({
  issuerAddress,
  subjectAddress,
  credentialType,
  claims,
  pdrId,
  expiryISO,
}) {
  const now = new Date().toISOString();

  return {
    "@context": [
      "https://www.w3.org/ns/credentials/v2",
      "https://pcc.protocol/context/v1",
    ],
    type: ["VerifiableCredential", "ComplianceCredential"],
    id: `https://pcc.protocol/credentials/${pdrId}`,
    issuer: {
      id: `did:xrpl:mainnet:${issuerAddress}`,
      name: "PCC Bridge",
    },
    validFrom: now,
    validUntil: expiryISO,
    credentialSubject: {
      id: `did:xrpl:mainnet:${subjectAddress}`,
      type: credentialType,
      ...claims,
    },
    policyDecisionRecord: {
      id: pdrId,
      ruleSetID: claims.ruleSet || "FATF-R16",
      schema: credentialType,
      xrplIssuer: issuerAddress,
      xrplSubject: subjectAddress,
      issuedAt: now,
    },
    // Proof field: in production, replaced by Ed25519 DataIntegrityProof
    proof: {
      type: "DataIntegrityProof",
      cryptosuite: "eddsa-rdfc-2022",
      verificationMethod: `did:xrpl:mainnet:${issuerAddress}#key-1`,
      proofPurpose: "assertionMethod",
      created: now,
      proofValue: "PLACEHOLDER_SIGN_WITH_BRIDGE_KEY", // replace with real sig
    },
  };
}

// ── Policy Decision Record ────────────────────────────────────────────────────

/**
 * buildPDR
 * Constructs the Policy Decision Record — the structured compliance artifact
 * that answers WHO, WHAT RULES, and WHEN/HOW for every credential event.
 *
 * The PDR is written to XRPL as a MemoData field (hex-encoded JSON, truncated).
 * The full PDR is published off-chain (IPFS or HTTPS) and linked via MemoData URI.
 *
 * @param {object} params
 * @param {object} params.vc        - The W3C VC 2.0 document
 * @param {string} params.vcHash    - SHA-256 hash of the VC JSON (off-chain anchor)
 * @param {string} params.txHash    - XRPL transaction hash (set after submission)
 * @returns {object} PDR document
 */
export function buildPDR({ vc, vcHash = "PENDING", txHash = "PENDING" }) {
  return {
    pdrVersion: "1.0",
    id: vc.policyDecisionRecord.id,
    timestamp: vc.validFrom,

    // WHO
    subject: {
      did: vc.credentialSubject.id,
      xrplAddress: vc.policyDecisionRecord.xrplSubject,
      type: vc.credentialSubject.type,
    },

    // WHAT RULES
    policy: {
      credentialSchema: vc.credentialSubject.type,
      ruleSetID:        vc.policyDecisionRecord.ruleSetID,
      kycTier:          vc.credentialSubject.kycTier   || "L2",
      jurisdiction:     vc.credentialSubject.jurisdiction || "US-FinCEN",
      kycVendor:        vc.credentialSubject.kycVendor  || "PCC-Bridge",
    },

    // WHEN / HOW
    issuance: {
      issuerDID:      vc.issuer.id,
      xrplIssuer:     vc.policyDecisionRecord.xrplIssuer,
      issuedAt:       vc.validFrom,
      expiresAt:      vc.validUntil,
      vcEnvelope:     "W3C-VC-2.0",
      vcHash,
      xrplTxHash:     txHash,
    },

    // PROPAGATION — in production, filled after relay to EVM / bank webhooks
    propagation: {
      xrpl:   true,
      evm:    false, // flip to true after EVM relay implementation
      bankApi: false, // flip to true after FDX / SWIFT adapter
    },

    // ECONOMICS
    burnEvent: {
      tokenSymbol: "$PCC",
      burnRate:    "0.5%",
      note:        "Simulated on testnet — no real $PCC exists yet",
    },

    status: "VALID",
  };
}

// ── XRPL Memo Encoding ───────────────────────────────────────────────────────

/**
 * buildMemos
 * Encodes PDR metadata as XRPL transaction memos.
 * XRPL memo fields have a practical limit of ~1KB each.
 * We write two memos:
 *   Memo 1: PDR summary (JSON, truncated to fit)
 *   Memo 2: URI pointing to the full PDR off-chain
 *
 * @param {object} pdr - PDR document
 * @returns {Array} XRPL Memos array
 */
export function buildMemos(pdr) {
  // Compact summary — safe to embed on-chain
  const summary = {
    id:         pdr.id,
    ts:         pdr.timestamp,
    sub:        pdr.subject.xrplAddress,
    schema:     pdr.policy.credentialSchema,
    ruleSet:    pdr.policy.ruleSetID,
    tier:       pdr.policy.kycTier,
    jur:        pdr.policy.jurisdiction,
    status:     pdr.status,
    pcc:        "v1",
  };

  const summaryJson = JSON.stringify(summary);

  return [
    {
      Memo: {
        MemoType: toHex("pcc/pdr"),
        MemoData: toHex(summaryJson),
        MemoFormat: toHex("application/json"),
      },
    },
    {
      Memo: {
        MemoType: toHex("pcc/pdr-uri"),
        // In production: IPFS CID or HTTPS URL of the full PDR document
        MemoData: toHex(`https://pcc.protocol/pdrs/${pdr.id}`),
        MemoFormat: toHex("text/uri"),
      },
    },
  ];
}

/**
 * decodeMemosToPDR
 * Extracts and decodes PCC PDR memos from an XRPL transaction.
 *
 * @param {Array} memos - XRPL transaction Memos array
 * @returns {{ summary: object|null, uri: string|null }}
 */
export function decodeMemosToPDR(memos = []) {
  let summary = null;
  let uri = null;

  for (const { Memo } of memos) {
    const type = Memo?.MemoType ? fromHex(Memo.MemoType) : "";
    const data = Memo?.MemoData ? fromHex(Memo.MemoData) : "";

    if (type === "pcc/pdr") {
      try { summary = JSON.parse(data); } catch { /* malformed */ }
    }
    if (type === "pcc/pdr-uri") {
      uri = data;
    }
  }

  return { summary, uri };
}
