// *******************************************************
// ******************** Get NFTokens *********************
// *******************************************************

async function getNFTokens () {
	let jason
	let ledger_entry_type
	let nfTokens
	let nftoken_data
	let results = ""
	let stateTree
	
  const client = new xrpl.Client('wss://xls20-sandbox.rippletest.net:51233')
	await client.connect()
  if (markerField.value.length == 64) {
		nftoken_data = await client.request({
			command: "ledger_data",
			id: "NFToken data request",
			limit: 200,
			marker: markerField.value
	  }) 
	} else {
		nftoken_data = await client.request({
			command: "ledger_data",
			id: "NFToken data request",
			limit: 200
		}) 
  }
	jason =  JSON.stringify(nftoken_data.result, null, 2)
	stateTree = JSON.parse(jason).state
  for (i=0; i < 200; i++) {
		ledger_entry_type = stateTree[i].LedgerEntryType
		if (ledger_entry_type == "NFTokenPage") {
			nfTokens = stateTree[i].NFTokens
			for (j=0; j < nfTokens.length; j++) {
				results += JSON.stringify(nfTokens[j])
			}
		}
	}
  client.disconnect()
	resultField.value = results
	markerField.value = nftoken_data.result.marker
}

// *******************************************************
// ******************* Get NFToken IDs *******************
// *******************************************************

async function getNFTokenIDs() {
	let jason
	let stateTree
	let ledger_entry_type
	let nfTokens
	let results = ""
	let nftoken_data
	let j_tokens
	let j_json
	  
  const client = new xrpl.Client('wss://xls20-sandbox.rippletest.net:51233')
	await client.connect()
  if (markerField.value.length == 64) {
		nftoken_data = await client.request({
			command: "ledger_data",
			id: "NFToken data request",
			limit: 200,
			marker: markerField.value
		})
  } else {
		nftoken_data = await client.request({
			command: "ledger_data",
			id: "NFToken data request",
			limit: 200
		}) 
  }
	jason =  JSON.stringify(nftoken_data.result, null, 2)
	stateTree = JSON.parse(jason).state
  for (i=0; i < 200; i++) {
		ledger_entry_type = stateTree[i].LedgerEntryType
		if (ledger_entry_type == "NFTokenPage") {
			nfTokens = stateTree[i].NFTokens
			for (j=0; j < nfTokens.length; j++) {
				j_tokens = JSON.stringify(nfTokens[j])
 				j_json = JSON.parse(j_tokens) 
 				results += j_json.NFToken.NFTokenID + "\n"
			}
		}
	}
  client.disconnect()
	resultField.value = results
	markerField.value = nftoken_data.result.marker
}

// *******************************************************
// ****************** Get NFToken Info *******************
// *******************************************************

async function getNFTokenInfo() {
  let nftoken_info
  let the_result

  const client = new xrpl.Client("wss://clionft.devnet.rippletest.net:51233")
  await client.connect()
	nftoken_info = await client.request({
	  "command": "nft_info",
	  "nft_id": NFTokenIDField.value
	})
	the_result = JSON.stringify(nftoken_info)
  client.disconnect()
	infoField.value += "NFToken ID........"   + JSON.parse(the_result).result.nft_id
	infoField.value += "\nIssuer............" + JSON.parse(the_result).result.issuer
  infoField.value += "\nOwner............." + JSON.parse(the_result).result.owner
	infoField.value += "\nFlags............." + JSON.parse(the_result).result.flags
	infoField.value += "\nIs Burned........." + JSON.parse(the_result).result.is_burned
	infoField.value += "\nLedger Index......" + JSON.parse(the_result).result.ledger_index
  infoField.value += "\nNFToken Sequence.." + JSON.parse(the_result).result.nft_sequence
  infoField.value += "\nNFToken Taxon....." + JSON.parse(the_result).result.nft_taxon
  infoField.value += "\nTransfer Fee......" + JSON.parse(the_result).result.transfer_fee
  infoField.value += "\nURI..............." + JSON.parse(the_result).result.uri
  infoField.value += "\nValidated........." + JSON.parse(the_result).result.validated + "\n\n"
}
